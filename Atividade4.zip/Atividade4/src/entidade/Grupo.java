package entidade;

import util.Categoria;

public class Grupo {
    private String nome;
    private int idadeMinUsuarioAnos;
    private int idadeMinPaginaDIas;
    private Usuario adm;
    private Usuario[] usuarios;
    private Categoria categoria;
}
