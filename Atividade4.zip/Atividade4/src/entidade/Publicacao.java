package entidade;

import java.util.Date;

public class Publicacao {
    private Date data;
    private String conteudo;
}
