package util;

public class Categoria {
    private String nome;
}
