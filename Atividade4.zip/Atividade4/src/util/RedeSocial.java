package util;

import entidade.Grupo;
import entidade.Usuario;

public class RedeSocial {
    private String nome;
    private Grupo[] grupos;
    private Usuario[] usuarios;
}
