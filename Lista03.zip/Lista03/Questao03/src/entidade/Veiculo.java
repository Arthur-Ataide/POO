package entidade;

public abstract class Veiculo {

    public abstract int getNumeroRodas();
    public abstract void acelerar(float velocidade);
    public abstract void parar();
}
