package entidade;

public class Papel implements Objeto{

    @Override
    public String getTipoString() {
        return "Papel";
    }

}
