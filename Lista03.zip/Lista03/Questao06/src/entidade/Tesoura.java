package entidade;

public class Tesoura implements Objeto{

    @Override
    public String getTipoString() {
        return "Tesoura";
    }
}
