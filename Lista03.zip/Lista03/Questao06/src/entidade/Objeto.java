package entidade;

public interface Objeto {

    public String getTipoString();
}
