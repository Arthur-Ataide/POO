package entidade;

public class Pedra implements Objeto{

    @Override
    public String getTipoString() {
        return "Pedra";
    }

}
