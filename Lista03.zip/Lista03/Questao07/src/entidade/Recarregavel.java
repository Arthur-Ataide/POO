package entidade;

public interface Recarregavel {
    void recarregar();
}
