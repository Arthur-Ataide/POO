package entidade;

public interface Ligavel {
    void ligar();
    void desligar();
}

