package entidade;

public interface AparelhoInteligente {
    public void conectarWifi();
    public void ligar();
    public void desligar();
}
