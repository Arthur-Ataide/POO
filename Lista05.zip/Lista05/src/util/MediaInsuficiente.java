package util;

public class MediaInsuficiente extends Exception {
    public MediaInsuficiente() {
        super("Média insuficiente");
    }
}
