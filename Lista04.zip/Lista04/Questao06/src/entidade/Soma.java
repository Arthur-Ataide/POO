package entidade;

public class Soma {
    public int doisValores(int a, int b)
    {
    System.out.println("M1");
    return a + b;
    }

    public double doisValores(double a, int b)
    {
    System.out.println("M2");
    return a + b;
    }

    public double doisValores(double a, double b)
    {
    System.out.println("M3");
    return a + b;
    }
}